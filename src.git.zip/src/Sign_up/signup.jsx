import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './signup.css';

const Signup = () => {
  const [userType, setUserType] = useState('seller'); // 'seller' or 'buyer'
  const [trackBy, setTrackBy] = useState('awb'); // 'awb' or 'orderId'
  const navigate = useNavigate();

  const handleUserTypeChange = (e) => {
    setUserType(e.target.value);
  };

  const handleTrackByChange = (e) => {
    setTrackBy(e.target.value);
  };

  const handleSellerSubmit = (e) => {
    e.preventDefault();
    alert("Seller form submitted");
    navigate('/edit'); 
  };

  const handleBuyerSubmit = (e) => {
    e.preventDefault();
    alert("Tracking order...");
  };

  return (
    <div className="container">
      {/* Left Section */}
      <div className="left-section">
        <h2>15,000+ online sellers prefer Yaarideal Logistics</h2>
        <p>Get an all-in-one shipping automation solution for fast-scaling.</p>
        <div className="logo-grid">
          <img src="https://app.shipway.com/images/signup/landing_signup/client-banner.png" alt="Logo" />
        </div>
      </div>

      {/* Right Section */}
      <div className="right-section">
        <div className="form-header">
          <label>
            <input
              type="radio"
              name="userType"
              value="seller"
              checked={userType === 'seller'}
              onChange={handleUserTypeChange}
            />
            I'm a Seller
          </label>
          <label>
            <input
              type="radio"
              name="userType"
              value="buyer"
              checked={userType === 'buyer'}
              onChange={handleUserTypeChange}
            />
            I'm a Buyer
          </label>
        </div>

        {/* Seller Form */}
        {userType === 'seller' && (
          <div className="seller-content">
            <h2>Start with a free account</h2>
            <button className="google-btn">
              <img src="/google-logo.png" alt="Google Logo" /> Sign in with Google
            </button>
            <p>OR</p>
            <form id="signup-form" onSubmit={handleSellerSubmit}>
              <input type="text" placeholder="Name" required />
              <input type="text" placeholder="Company name" required />
              <input type="email" placeholder="Work Email" required />
              <div className="phone-container">
                <select>
                  <option>+91</option>
                  <option>+1</option>
                  <option>+44</option>
                </select>
                <input type="text" placeholder="Phone" required />
              </div>
              <input type="password" placeholder="Password" required />
              <select required defaultValue="">
                <option value="" disabled>Select Monthly Order Volume</option>
                <option>0-100</option>
                <option>101-500</option>
                <option>501-1000</option>
                <option>1000+</option>
              </select>
              <div className="recaptcha">
                <label>
                  <input type="checkbox" required /> I'm not a robot
                </label>
              </div>
              <button type="submit" className="submit-btn">Sign Up</button>
            </form>
          </div>
        )}

        {/* Buyer Form */}
        {userType === 'buyer' && (
          <div className="buyer-content">
            <h2>Track your orders</h2>
            <form id="buyer-form" onSubmit={handleBuyerSubmit}>
              <div className="track-options">
                <label>
                  <input
                    type="radio"
                    name="trackBy"
                    value="awb"
                    checked={trackBy === 'awb'}
                    onChange={handleTrackByChange}
                  />
                  AWB
                </label>
                <label>
                  <input
                    type="radio"
                    name="trackBy"
                    value="orderId"
                    checked={trackBy === 'orderId'}
                    onChange={handleTrackByChange}
                  />
                  Order ID
                </label>
              </div>

              {/* AWB Input */}
              {trackBy === 'awb' && (
                <div className="input-container awb-input">
                  <input type="text" placeholder="Enter AWB Number" required />
                </div>
              )}

              {/* Order ID Input */}
              {trackBy === 'orderId' && (
                <div className="input-container order-id-input">
                  <input type="text" placeholder="Enter Order ID" required />
                  <br /><br />
                  <input type="text" placeholder="Enter Phone Number/Email" required />
                </div>
              )}

              <button type="submit" className="submit-btn">Track Order</button>
            </form>
            <p>Where to find order details?</p>
            <p>We have sent you the Order ID/Tracking number to your registered phone number via SMS or WhatsApp.</p>
          </div>
        )}
      </div>

      <p className="login-redirect">
        Already have an account? <a href="/login">Log in</a>
      </p>
    </div>
  );
};

export default Signup;
