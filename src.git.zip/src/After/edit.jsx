import React, { useState, useEffect } from 'react';
import './Edit.css'; // Assuming the CSS file is named 'Edit.css'

function OrdersPage() {
    const [activeTab, setActiveTab] = useState('new-orders');
    const [showKYC, setShowKYC] = useState(true);

    // Switch the active tab
    const showTab = (tabId) => {
        setActiveTab(tabId);
    };

    // Show KYC message when component mounts
    useEffect(() => {
        if (showKYC) {
            alert("Your KYC is not approved");
            setShowKYC(false); // To ensure the message only appears once
        }
    }, [showKYC]);

    return (
        <div>
            {/* Top Navbar */}
            <nav className="top-nav">
                <div className="logo">Shipway</div>
                <div className="search-container">
                    <input type="text" className="search-box" placeholder="Search..." />
                </div>
                <a href="contact.html" className="contact-link">Need Help! Contact Us</a>
                <div className="icons">
                    <span className="notification-icon">🔔</span>
                    <div className="profile-dropdown">
                        <div className="profile-icon">M</div>
                        <div className="dropdown-content">
                            <a href="#">Profile</a>
                            <a href="#">Logout</a>
                        </div>
                    </div>
                </div>
            </nav>

            {/* Secondary Navbar */}
            <nav className="secondary-nav">
                <ul>
                    <li><a href="#home">🏠</a></li>
                    <li><a href="Dashboard.html">Dashboard</a></li>
                    <li className="has-dropdown">
                        <a href="#orders">Orders</a>
                        <div className="dropdown">
                            <a href="edit.html">View Orders</a>
                            <a href="bulk-ord.html">Bulk Orders Import</a>
                            <a href="on-hold.html">On Hold Orders</a>
                            <a href="unfulfilled.html">Unfulfilled Orders</a>
                            <a href="unpushed.html">Unpushed Orders</a>
                            <a href="bulk-invo.html">Bulk Invoice</a>
                        </div>
                    </li>
                    <li className="has-dropdown">
                        <a href="#returns">Returns</a>
                        <div className="dropdown">
                            <a href="view.html">View Returns</a>
                            <a href="pickup.html">Pickup Failed Report</a>
                            <a href="refund.html">Refunds</a>
                        </div>
                    </li>
                    <li className="has-dropdown">
                        <a href="#wallet">Wallet</a>
                        <div className="dropdown">
                            <a href="recharge.html">Wallet Recharge</a>
                            <a href="kyc.html">KYC</a>
                            <a href="billing.html">Billing</a>
                            <a href="ratecard.html">Rate Card</a>
                            <a href="courier.html">Manage Courier</a>
                            <a href="warehouse.html">Manage Warehouse</a>
                        </div>
                    </li>
                    <li><a href="tracks.html">Track</a></li>
                </ul>
            </nav>

            {/* Main Content */}
            <main id="content">
                <div id="orders-section">
                    {/* KYC Notification */}
                    {showKYC && (
                        <div className="kyc-notification">
                            <p>Your KYC is not approved. <a href="blank.html">Click here</a> to update your KYC details.</p>
                        </div>
                    )}

                    {/* Tabs */}
                    <div className="tabs">
                        <button 
                            className={`tab-button ${activeTab === 'new-orders' ? 'active' : ''}`}
                            onClick={() => showTab('new-orders')}
                        >
                            New Orders
                        </button>
                        <button 
                            className={`tab-button ${activeTab === 'process-orders' ? 'active' : ''}`}
                            onClick={() => showTab('process-orders')}
                        >
                            Process Orders
                        </button>
                        <button 
                            className={`tab-button ${activeTab === 'track-orders' ? 'active' : ''}`}
                            onClick={() => showTab('track-orders')}
                        >
                            Track
                        </button>
                        <button 
                            className={`tab-button ${activeTab === 'all-orders' ? 'active' : ''}`}
                            onClick={() => showTab('all-orders')}
                        >
                            All Orders
                        </button>
                    </div>

                    {/* Tab Content */}
                    <div id="tab-content">
                        <div id="new-orders" className={`tab ${activeTab === 'new-orders' ? 'active' : ''}`}>
                            <p>No new orders found.</p>
                        </div>
                        <div id="process-orders" className={`tab ${activeTab === 'process-orders' ? 'active' : ''}`}>
                            <p>No process orders found.</p>
                        </div>
                        <div id="track-orders" className={`tab ${activeTab === 'track-orders' ? 'active' : ''}`}>
                            <p>No tracking data available.</p>
                        </div>
                        <div id="all-orders" className={`tab ${activeTab === 'all-orders' ? 'active' : ''}`}>
                            <p>No orders found.</p>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}

export default OrdersPage;
