import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Import the router components
import Home from './Main/home'; // Ensure 'Home' component is correctly imported
import Signup from './Sign_up/signup'; // Ensure 'Signup' component is correctly imported
import Login from './LOg-in/login'; // Ensure 'Login' component is correctly imported
import OrdersPage from './After/edit';
import TrackPage from './tra-ck/tracks';
import Blogs from './Main/blogs';
import FeaturesPage from './Main/features';
import ResourcesPage from './Main/resources';
import AboutUs from './Rest/about';
import ContactUs from './Rest/contact';
import Profile from './Rest/profile';
import blank from './Rest/blank';
import imports from './Rest/imports';
import BillingPage from './Dash-board/billing';
import Orders from './Dash-board/bulk-invo';
import BulkPage from './Dash-board/bulk-ord';
import CourierPage from './Dash-board/courier';
import DashPage from './Dash-board/Dashboard';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} /> {/* Home page */}
        <Route path="/signup" element={<Signup />} /> {/* Signup page */}
        <Route path="/login" element={<Login />} /> {/* Login page */}
        <Route path="/edit" element={<OrdersPage />} /> {/*Edit page */}
        <Route path="/tracks" element={<TrackPage />} /> {/* Track page */}
        <Route path="/blogs" element={<Blogs />} /> {/*Edit page */}
        <Route path="/features" element={<FeaturesPage />} /> {/*Edit page */}
        <Route path="/resources" element={<ResourcesPage />} /> {/*Edit page */}
        <Route path="/about" element={<AboutUs />} /> {/*Edit page */}
        <Route path="/contact" element={<ContactUs />} /> {/*Edit page */}
        <Route path="/profile" element={<Profile/>} /> {/*Edit page */}
        <Route path="/blank" element={<blank />} /> {/*Edit page */}
        <Route path="/imports" element={<imports />} /> {/*Edit page */}
        <Route path="/imports" element={<BillingPage />} /> {/*Edit page */}
        <Route path="/imports" element={<Orders />} /> {/*Edit page */}
        <Route path="/imports" element={<BulkPage />} /> {/*Edit page */}
        <Route path="/imports" element={<CourierPage />} /> {/*Edit page */}
        <Route path="/imports" element={<DashPage />} /> {/*Edit page */}  
      </Routes>
    </Router>
  );
}

export default App;
