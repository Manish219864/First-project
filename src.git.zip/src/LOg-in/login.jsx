import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom'; // Import Link from react-router-dom
import './login.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const navigate = useNavigate(); // Initialize useNavigate hook

  const handlePasswordToggle = () => {
    setPasswordVisible(!passwordVisible);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const storedEmail = localStorage.getItem('userEmail');
    const storedPassword = localStorage.getItem('userPassword');

    if (email === storedEmail && password === storedPassword) {
      alert('Login successful!');
      navigate('/edit'); // Use navigate from react-router for page redirection
    } else {
      alert('Invalid credentials. Please sign up first!');
    }
  };

  return (
    <div className="container">
      {/* Left Section */}
      <div className="left-text">
        <img
          src="https://res.cloudinary.com/dla5rblx7/images/v1730530036/parcellogo_2-hd/parcellogo_2-hd.png?_i=AA"
          alt="Company Logo"
          className="company-logo"
        />
        <h1>Welcome to Parcel Mitra</h1>
        <p>
          The Logistics Super App to Power your<br /> D2C Growth
        </p>
        <img
          src="https://app.shipway.com/images/signup/Image-bg.png"
          className="bottom-image"
          alt="Bottom Image"
        />
      </div>

      {/* Login Section */}
      <div>
        <div className="login-box">
          <div className="login-container">
            <h1>Happy Login!</h1>
            <button className="google-login-btn">
              <img
                src="google-logo.png"
                className="google-logo"
                alt="Google Logo"
              />
              Sign in with Google
            </button>
            <br />
            <br />
            <div className="separator">
              <span>---------------------------- OR ----------------------------</span>
            </div>
            {/* Login Form */}
            <form className="login-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <input
                  type="email"
                  placeholder="Email ID"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <br />
              <div className="form-group password-field">
                <input
                  type={passwordVisible ? 'text' : 'password'}
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <span className="toggle-password" onClick={handlePasswordToggle}>
                  👁
                </span>
              </div>
              <br />
              <button type="submit" className="submit-btn">
                Login
              </button>
            </form>

            <p>
              New to ParcelMitra.in? <Link to="/signup">Click Here</Link> {/* Use Link here */}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
